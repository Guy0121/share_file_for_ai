from pathlib import Path
from PIL import Image,ImageDraw,ImageChops,ImageOps
from functools import lru_cache
import json,math,subprocess,io,os
R=Path(__file__).parent;M=json.loads((R/'assets_manifest.json').read_text());W,H=1280,720;K=W/1920
@lru_cache(maxsize=80)
def asset(n):return Image.open(R/M[n]['file']).convert('RGBA')
@lru_cache(maxsize=36)
def sized(n,w,h,flip,black,fade):
 im=asset(n).resize((w,h),Image.Resampling.LANCZOS)
 if black:im=Image.new('RGBA',im.size,(0,0,0,0)).copy() if False else Image.merge('RGBA',(Image.new('L',im.size,0),)*3+(im.getchannel('A'),))
 if fade:
  strip=Image.new('L',(1,h));strip.putdata([round(255*max(0,min(1,(.88-y/h)/.18)))for y in range(h)]);im.putalpha(ImageChops.multiply(im.getchannel('A'),strip.resize((w,h))))
 if flip:im=ImageOps.flip(im)
 return im
def render(ls):
 out=Image.new('RGBA',(W,H),'#f1e9da')
 for l in ls:
  if l['op']<=.001:continue
  if l['type']=='rect':
   lay=Image.new('RGBA',(max(1,round(l['w']*K)),max(1,round(l['h']*K))),l['color']);lay.putalpha(round(l['op']*255));out.alpha_composite(lay,(round(l['x']*K),round(l['y']*K)));continue
  aw,ah=M[l['asset']]['size'];f=min(l['w']/aw,l['h']/ah);w,h=aw*f,ah*f;x=l['x']+(l['w']-w)/2;y=l['y']+l['h']-h;s=l.get('scale',1);x-=w*(s-1)/2;y-=h*(s-1)/2;w*=s;h*=s
  im=sized(l['asset'],max(1,round(w*K)),max(1,round(h*K)),l.get('flipY',False),l.get('black',False),l.get('fade',False))
  if l.get('rotate',0):
   rot=im.rotate(-l['rotate'],Image.Resampling.BICUBIC,expand=True);x-=(rot.width-im.width)/(2*K);y-=(rot.height-im.height)/(2*K);im=rot
  if l['op']<.999:im=im.copy();im.putalpha(im.getchannel('A').point(lambda p:round(p*l['op'])))
  
  if l.get('clip'):
   lay=Image.new('RGBA',(W,H));lay.alpha_composite(im,(round(x*K),round(y*K)));c=l['clip'];mask=Image.new('L',(W,H));ImageDraw.Draw(mask).rectangle((round(c['x']*K),round(c['y']*K),round((c['x']+c['w'])*K),round((c['y']+c['h'])*K)),fill=255);lay.putalpha(ImageChops.multiply(lay.getchannel('A'),mask));out.alpha_composite(lay)
  else:out.alpha_composite(im,(round(x*K),round(y*K)))
 return out.convert('RGB')
def save_atomic(im,path):
 b=io.BytesIO();im.save(b,format='PNG');tmp=path.with_suffix('.bin');tmp.write_bytes(b.getvalue());os.replace(tmp,path)
if __name__=='__main__':
 checks=json.loads((R/'render_checks.json').read_text())
 for f in checks:
  if f['u']==.5:save_atomic(render(f['layers']),R/'previews'/f"{f['id']:02}.png")
 # Four contact sheets, 8 shots each, for composition verification.
 for sheet in range(4):
  contact=Image.new('RGB',(1280,800),'#eee6d8');d=ImageDraw.Draw(contact)
  for k in range(8):
   sid=sheet*8+k+1;im=Image.open(R/'previews'/f'{sid:02}.png').resize((320,180));x=(k%4)*320;y=(k//4)*400;contact.paste(im,(x,y+30));d.text((x+12,y+8),f'SCENE {sid:02}',fill='#222222');
   # Start and end strips below show actual change, not merely a still.
   ff=[q for q in checks if q['id']==sid]
   for j,q in enumerate([ff[0],ff[-1]]):contact.paste(render(q['layers']).resize((160,90)),(x+j*160,y+225))
  save_atomic(contact,R/'previews'/f'contact_{sheet+1:02}.png')
 print('Composition sheets ready',flush=True)
 frames=json.loads((R/'render_frames.json').read_text())
 p=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','12','-i','-','-an','-vf','fps=24','-c:v','libx264','-preset','fast','-crf','22','-pix_fmt','yuv420p','-movflags','+faststart',str(R/'橋姫_全32カット_動き確認.mp4')],stdin=subprocess.PIPE)
 for j,f in enumerate(frames):
  p.stdin.write(render(f['layers']).tobytes())
  if j%288==0:print('Rendered scene',f['id'],flush=True)
 p.stdin.close();assert p.wait()==0
 print('Video ready',flush=True)
