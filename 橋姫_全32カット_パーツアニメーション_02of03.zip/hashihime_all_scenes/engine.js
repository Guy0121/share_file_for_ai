/* Shared scene layout: SVG player, standalone SVG exports and MP4 use these layers. */
(function(root){
const clamp=x=>Math.max(0,Math.min(1,x)), ease=x=>{x=clamp(x);return x*x*(3-2*x)}, lerp=(a,b,u)=>a+(b-a)*u;
function layers(id,u){
 u=clamp(u);const s=[], img=(asset,x,y,w,h,p={})=>s.push({type:'image',asset,x,y,w,h,op:1,...p}),rect=(color,op=1)=>s.push({type:'rect',color,op,x:0,y:0,w:1920,h:1080});
 const bg=(asset='home',op=1)=>img(asset,0,0,1920,1080,{op});
 const night=a=>rect('#152027',a), ink=(op,x=-250,y=0,w=2400,h=1150)=>img('ink',x,y,w,h,{op,black:true});
 const mask=(zoom=1,dx=0,dy=0,op=1)=>img('mask',960-350*zoom+dx,540-490*zoom+dy,700*zoom,980*zoom,{op});
 const river=(day=true)=>{bg('river');img('ritual',350,70,600,900,{fade:true});img('water',-130+35*Math.sin(u*6.28),110+3*Math.sin(u*12.56),2200,1050,{op:.85});img('leaf',-160+2180*u,815+12*Math.sin(u*8),180,120);night(day?.58*(1-ease((u-.18)/.64)):.48)};
 rect('#f1e9da');
 switch(id){
 case 1:bg();img('couple',1090,280,600,650,{op:.4*(1-ease(u))});img('seated',230,200,800,800);break;
 case 2:bg('home',.25);img('seated',100,200,750,820);img('couple',1100,250,600,780,{op:.7});img('couple',1100,250,600,780,{black:true,op:ease((u-.2)/.65)});ink(.15*ease(u),950,150,1100,950);break;
 case 3:rect('#171816');mask(lerp(.78,.93,ease(u)),0,0,ease(u*3));break;
 case 4:rect('#171816');mask(lerp(1.5,1.95,ease(u*2)),0,0);break;
 case 5:bg('shrine');img('kneeling',390,560,380,430);night(.12+.33*(.5-.5*Math.cos(u*12.56)));break;
 case 6:bg('shrine',.6);img('kneeling',300,320,650,730);night(.12+.30*ease(u));break;
 case 7:bg();img('ritual',450-90*u,-20-80*u,850+160*u,1275+240*u);break;
 case 8:bg('home',.3);img('trivet',680,350-120*ease(u),560,400,{rotate:180,op:1-ease((u-.5)*3)});img('ritual',550,30,760,1140,{op:ease((u-.5)*3)});break;
 case 9:bg('home',.3);img('trivet',600,600,700,400);img('pot',570,220,760,500);break;
 case 10:bg('home',.3);img('trivet',610,520,700,460,{rotate:180*ease((u-.35)/.6)});img('pot',570,220-950*ease(u/.55),760,500);break;
 case 11:bg('home',.25);img('ritual',550,40,760,1140);ink(.12*ease(u));break;
 case 12:bg('shrine');img('walking',lerp(180,490,ease(u)),lerp(390,450,ease(u)),360-60*u,600-90*u);night(.48);break;
 case 13:river(false);break;
 case 14:river(true);break;
 case 15:bg('river',.5);img('couple',1150,120,500,580,{op:.65*Math.sin(Math.PI*ease(u))});img('grip',100,120,1080,1050,{scale:lerp(.92,1.06,ease(u))});night(.1);break;
 case 16:bg('river');img('foot',lerp(510,700,Math.sin(Math.PI*u)),350,950,700);img('water',-130+20*u,200,2200,900,{op:.45});ink(.65*ease((u-.8)*5));break;
 case 17:river(false);img('ghost',230,20-100*u,1300,1150,{op:ease(u),black:true});ink(.35*ease(u));break;
 case 18:img('seated',70,200,720,830);img('standing',850,200,300,800);img('standing',850,200,300,800,{black:true,op:ease(u*3)});img('couple',1210,270,610,740,{op:.55});img('couple',1210,270,610,740,{black:true,op:ease((u-.25)/.6)});ink(.3*ease((u-.25)/.75),700,100,1450,1100);break;
 case 19:bg('street',.3);s.push({type:'rect',color:'#272724',op:1,x:490,y:110,w:940,h:970});img('man',900,230,450,700);img('door',lerp(-100,492,ease(u)),110,1000,1040,{clip:{x:590,y:210,w:800,h:820}});img('frame',420,40,1150,1050);break;
 case 20:bg('street');img('standing',950,570,160,440,{black:true,op:.75});night(.24);break;
 case 21:case 22:bg('bridge');img('standing',400,160,400,530);img('mounted',1000,120,600,570);img('claw',200+180*ease(u),690,900+250*ease(u),330,{op:id===22?.7*ease(u):0,black:true,flipY:true});night(.24);break;
 case 23:bg('bridge',.2);img('grab_action',100,-20,1720,1170,{scale:1+.07*u});rect('#f1e9da',Math.max(0,1-Math.abs(u-.8)/.025)*.9);break;
 case 24:bg('bridge');img('warrior',870,80,450,630);img('ghost',lerp(500,1670,ease(u)),lerp(250,-650,ease(u)),850,850,{op:1-ease((u-.55)/.4),black:true});night(.27);break;
 case 25:case 26:bg('home',id===25?.6:.6*(1-ease(u)));img('bowl',180,520,450,400,{op:id===25?ease(u*4):1-ease(u*2)});img('garden',1150,210,600,600,{op:id===25?ease((u-.15)*4):1-ease((u-.2)*2)});img('companion',680,250,500,780,{op:id===25?ease((u-.35)*4):1-ease((u-.35)*2)});img('rival_face',1160,160,580,850,{op:id===26?ease((u-.5)*2):0});break;
 case 27:img('rival_face',570,60,780,960,{scale:1+.08*u});break;
 case 28:bg('home',.13);img('rival_face',570,60,780,960);night(.45*(.5-.5*Math.cos(u*12.56)));break;
 case 29:{bg('home',.2);const k=Math.min(3,Math.floor(u*4));img('ritual',510,-120,850,1275,{op:k===0?1:0});img('trivet',500,180,900,650,{rotate:180,op:k===1?1:0});img('tie_hands',400,180,1120,820,{op:k===2?1:0});img('foot',400,250,1150,800,{op:k===3?1:0});break;}
 case 30:img('open_hand',350,160,1220,850);break;
 case 31:rect('#171816');mask(.94+.06*ease(u*2));break;
 case 32:rect('#171816');mask(1.7+.45*ease(u*1.6),-150,0);rect('#111310',ease((u-.78)/.22));break;
 }
 return s;
}
function layout(l,meta){let {x,y,w,h}=l;if(l.type==='image'){const [aw,ah]=meta[l.asset].size,f=Math.min(w/aw,h/ah),nw=aw*f,nh=ah*f;x+=(w-nw)/2;y+=h-nh;w=nw;h=nh}return{x,y,w,h}}
function markup(id,u,assets,meta){const ls=layers(id,u);let defs='<filter id="black"><feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0"/></filter>',body='';ls.forEach((l,i)=>{const z=layout(l,meta);if(l.type==='rect'){body+=`<rect x="${l.x}" y="${l.y}" width="${l.w}" height="${l.h}" fill="${l.color}" opacity="${l.op}"/>`;return}let {x,y,w,h}=z,cx=x+w/2,cy=y+h/2;let trans=`translate(${cx} ${cy}) rotate(${l.rotate||0}) scale(${l.scale||1} ${(l.scale||1)*(l.flipY?-1:1)}) translate(${-cx} ${-cy})`;let clip='';if(l.clip){let c=l.clip;defs+=`<clipPath id="c${i}"><rect x="${c.x}" y="${c.y}" width="${c.w}" height="${c.h}"/></clipPath>`;clip=` clip-path="url(#c${i})"`;}let mask='';if(l.fade){defs+=`<linearGradient id="g${i}" x1="0" y1="0" x2="0" y2="1"><stop offset=".70" stop-color="white"/><stop offset=".88" stop-color="black"/></linearGradient><mask id="m${i}" maskUnits="userSpaceOnUse"><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#g${i})"/></mask>`;mask=` mask="url(#m${i})"`;}body+=`<g data-layer="${l.asset}" opacity="${l.op}" transform="${trans}"${clip}><image href="${assets[l.asset]}" x="${x}" y="${y}" width="${w}" height="${h}"${mask}${l.black?' filter="url(#black)"':''}/></g>`});return`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080"><defs>${defs}</defs>${body}</svg>`}
const api={layers,layout,markup};if(typeof module!=='undefined')module.exports=api;root.Hashihime=api;
})(typeof window!=='undefined'?window:globalThis);
